# Merkle - Software Developer Candidate Exercise
Merkle solution for Software Developer Candidate Exercise

- **Author**: Javier Rodriguez Gonzalez
- **Date**: 07/29/2020